#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\devlop\flutter"
export "FLUTTER_APPLICATION_PATH=D:\ứng dụng di động đa nền tảng\Nguyễn Hoàng Thân_2424801030021 TH4"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=D:\ứng dụng di động đa nền tảng\Nguyễn Hoàng Thân_2424801030021 TH4\macos\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
