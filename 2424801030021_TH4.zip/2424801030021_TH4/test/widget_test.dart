import 'package:flutter_test/flutter_test.dart';
import 'package:vnexpress_news_app/main.dart';

void main() {
  testWidgets('NewsApp smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const NewsApp());
    expect(find.text('ĐỌC BÁO ONLINE'), findsOneWidget);
  });
}
