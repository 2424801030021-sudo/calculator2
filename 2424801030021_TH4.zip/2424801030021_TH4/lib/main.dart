import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NewsApp());
}

// ==========================================
// 1. MODEL
// ==========================================
class Article {
  final String title;
  final String description;
  final String pubDate;
  final String link;
  final String? imageUrl;
  final String category;

  Article({
    required this.title,
    required this.description,
    required this.pubDate,
    required this.link,
    this.imageUrl,
    this.category = 'Tổng hợp',
  });
}

// ==========================================
// 2. RSS SERVICE
// ==========================================
class CategoryItem {
  final String name;
  final String rssUrl;
  final IconData icon;

  const CategoryItem({
    required this.name,
    required this.rssUrl,
    required this.icon,
  });
}

class RssService {
  static const List<CategoryItem> categories = [
    CategoryItem(
      name: 'Thời sự',
      rssUrl: 'https://vnexpress.net/rss/thoi-su.rss',
      icon: Icons.newspaper,
    ),
    CategoryItem(
      name: 'Thế giới',
      rssUrl: 'https://vnexpress.net/rss/the-gioi.rss',
      icon: Icons.public,
    ),
    CategoryItem(
      name: 'Kinh doanh',
      rssUrl: 'https://vnexpress.net/rss/kinh-doanh.rss',
      icon: Icons.trending_up,
    ),
    CategoryItem(
      name: 'Giải trí',
      rssUrl: 'https://vnexpress.net/rss/giai-tri.rss',
      icon: Icons.movie_outlined,
    ),
    CategoryItem(
      name: 'Thể thao',
      rssUrl: 'https://vnexpress.net/rss/the-thao.rss',
      icon: Icons.sports_soccer,
    ),
    CategoryItem(
      name: 'Pháp luật',
      rssUrl: 'https://vnexpress.net/rss/phap-luat.rss',
      icon: Icons.gavel,
    ),
    CategoryItem(
      name: 'Giáo dục',
      rssUrl: 'https://vnexpress.net/rss/giao-duc.rss',
      icon: Icons.school_outlined,
    ),
    CategoryItem(
      name: 'Sức khỏe',
      rssUrl: 'https://vnexpress.net/rss/suc-khoe.rss',
      icon: Icons.health_and_safety_outlined,
    ),
    CategoryItem(
      name: 'Đời sống',
      rssUrl: 'https://vnexpress.net/rss/gia-dinh.rss',
      icon: Icons.family_restroom,
    ),
    CategoryItem(
      name: 'Du lịch',
      rssUrl: 'https://vnexpress.net/rss/du-lich.rss',
      icon: Icons.flight_takeoff,
    ),
    CategoryItem(
      name: 'Khoa học',
      rssUrl: 'https://vnexpress.net/rss/khoa-hoc.rss',
      icon: Icons.biotech,
    ),
    CategoryItem(
      name: 'Số hóa',
      rssUrl: 'https://vnexpress.net/rss/so-hoa.rss',
      icon: Icons.devices,
    ),
    CategoryItem(
      name: 'Xe',
      rssUrl: 'https://vnexpress.net/rss/oto-xe-may.rss',
      icon: Icons.directions_car,
    ),
  ];

  static Future<List<Article>> fetchArticles(String url, {int? limit, String category = 'Tổng hợp'}) async {
    try {
      final response = await http
          .get(
            Uri.parse(url),
            headers: {
              'User-Agent':
                  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            },
          )
          .timeout(const Duration(seconds: 12));

      if (response.statusCode == 200) {
        final decodedXml = utf8.decode(response.bodyBytes);
        final articles = parseRss(decodedXml, category: category);
        if (articles.isNotEmpty) {
          if (limit != null && articles.length > limit) {
            return articles.sublist(0, limit);
          }
          return articles;
        }
      }
    } catch (_) {
      // Fallback offline mock data if connection fails
    }

    return getFallbackArticles(category: category, limit: limit);
  }

  static List<Article> parseRss(String xmlString, {String category = 'Tổng hợp'}) {
    final List<Article> list = [];
    final itemPattern = RegExp(r'<item>(.*?)<\/item>', dotAll: true);
    final matches = itemPattern.allMatches(xmlString);

    for (final match in matches) {
      final itemContent = match.group(1) ?? '';

      // Title
      final titleMatch = RegExp(r'<title>(.*?)<\/title>', dotAll: true).firstMatch(itemContent);
      String title = titleMatch?.group(1) ?? '';
      title = cleanCdata(title);

      // Description
      final descMatch = RegExp(r'<description>(.*?)<\/description>', dotAll: true).firstMatch(itemContent);
      String rawDesc = descMatch?.group(1) ?? '';
      rawDesc = cleanCdata(rawDesc);

      // Extract image URL: check enclosure first, then img tag in description
      String? imageUrl;
      final enclosureMatch = RegExp(r'<enclosure[^>]+url=["' "'" r']([^"' "'" r']+)["' "'" r']', caseSensitive: false)
          .firstMatch(itemContent);
      if (enclosureMatch != null) {
        imageUrl = enclosureMatch.group(1);
      } else {
        final imgMatch = RegExp(r'<img[^>]+src=["' "'" r']([^"' "'" r']+)["' "'" r']', caseSensitive: false)
            .firstMatch(rawDesc);
        if (imgMatch != null) {
          imageUrl = imgMatch.group(1);
        }
      }

      if (imageUrl != null) {
        imageUrl = imageUrl.replaceAll('&amp;', '&').trim();
      }

      // Clean HTML tags to get pure description text
      String cleanDescription = rawDesc
          .replaceAll(RegExp(r'<a[^>]*>.*?<\/a>', caseSensitive: false, dotAll: true), '')
          .replaceAll(RegExp(r'<[^>]*>'), '')
          .trim();
      cleanDescription = cleanDescription
          .replaceAll('&quot;', '"')
          .replaceAll('&apos;', "'")
          .replaceAll('&#39;', "'")
          .replaceAll('&amp;', '&')
          .replaceAll('&lt;', '<')
          .replaceAll('&gt;', '>')
          .replaceAll('&nbsp;', ' ')
          .trim();

      // Link
      final linkMatch = RegExp(r'<link>(.*?)<\/link>', dotAll: true).firstMatch(itemContent);
      String link = linkMatch?.group(1) ?? '';
      link = cleanCdata(link).trim();

      // PubDate
      final pubDateMatch = RegExp(r'<pubDate>(.*?)<\/pubDate>', dotAll: true).firstMatch(itemContent);
      String pubDate = pubDateMatch?.group(1) ?? '';
      pubDate = cleanCdata(pubDate).trim();
      pubDate = formatPubDate(pubDate);

      if (title.isNotEmpty) {
        list.add(
          Article(
            title: title,
            description: cleanDescription,
            pubDate: pubDate,
            link: link,
            imageUrl: imageUrl,
            category: category,
          ),
        );
      }
    }

    return list;
  }

  static String cleanCdata(String input) {
    var result = input.replaceAll('<![CDATA[', '').replaceAll(']]>', '');
    return result.trim();
  }

  static String formatPubDate(String rawDate) {
    if (rawDate.isEmpty) return 'Hôm nay';
    try {
      // E.g. Tue, 29 Sep 2026 15:10:00 +0700
      final parts = rawDate.split(' ');
      if (parts.length >= 4) {
        return '${parts[1]} ${parts[2]} ${parts[3]}';
      }
    } catch (_) {}
    return rawDate;
  }

  static List<Article> getFallbackArticles({String category = 'Tổng hợp', int? limit}) {
    final list = [
      Article(
        title: 'Tầm soát ung thư tuyến tiền liệt miễn phí 1.000 nam giới từ 50 tuổi',
        description:
            'Chương trình tầm soát và tư vấn miễn phí phát hiện sớm ung thư tiền liệt tuyến cho người từ 50 tuổi trở lên.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/suc-khoe',
        imageUrl:
            'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Trà xanh chứa bao nhiêu caffeine?',
        description:
            'Một tách trà xanh chứa khoảng 20-45 mg caffeine, thấp hơn cà phê nhưng đủ để giúp tinh thần tỉnh táo.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/suc-khoe',
        imageUrl:
            'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Xuất tinh hơn 21 lần trong tháng có thể ngừa ung thư tuyến tiền liệt',
        description:
            'Nghiên cứu của Đại học Harvard chỉ ra thói quen này giúp giảm nguy cơ mắc bệnh tuyến tiền liệt ở nam giới.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/suc-khoe',
        imageUrl:
            'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Các hãng dầu khí tìm nơi khai thác mới ngoài Trung Đông',
        description:
            'Căng thẳng địa chính trị thúc đẩy các tập đoàn năng lượng đa dạng hóa nguồn cung và đẩy mạnh khai thác ngoài vùng vịnh.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/kinh-doanh',
        imageUrl:
            'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Mỹ chạy đua tự chủ đất hiếm để giảm phụ thuộc Trung Quốc',
        description:
            'Chính phủ Mỹ tăng cường tài trợ chuỗi cung ứng vật liệu pin xe điện và nam châm vĩnh cửu.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/kinh-doanh',
        imageUrl:
            'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Nơi 13 liệt sĩ hy sinh khi cứu hộ ở Rào Trăng trở thành di tích lịch sử',
        description:
            'Khu vực Trạm kiểm lâm 67 nơi 13 cán bộ, chiến sĩ hy sinh được công nhận di tích lịch sử cấp tỉnh.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/thoi-su',
        imageUrl:
            'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: '4 con giáp bước vào chu kỳ thành công rực rỡ',
        description:
            'Tử vi dự báo thời điểm thuận lợi đón nhận nhiều cơ hội tài chính và thăng tiến trong công việc.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/doi-song',
        imageUrl:
            'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Real Madrid vs Barcelona: Trận El Clasico định đoạt chức vô địch',
        description:
            'Trận siêu kinh điển Tây Ban Nha giữa hai thế lực bóng đá đỉnh cao thu hút sự quan tâm của hàng triệu người hâm mộ.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/the-thao',
        imageUrl:
            'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Việt Nam sắp lắp đặt thêm mạng lưới trạm đo bức xạ tự động',
        description:
            'Hệ thống quan trắc hiện đại giúp theo dõi môi trường phóng xạ và cảnh báo sớm các sự cố hạt nhân xuyên biên giới.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/khoa-hoc',
        imageUrl:
            'https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
      Article(
        title: 'Trí tuệ nhân tạo thế hệ mới thay đổi cách con người làm việc',
        description:
            'Các công cụ AI tạo sinh đang nâng cao năng suất và tạo ra bước chuyển dịch lớn trên thị trường lao động toàn cầu.',
        pubDate: '21 Apr 2026',
        link: 'https://vnexpress.net/so-hoa',
        imageUrl:
            'https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&w=400&q=80',
        category: category,
      ),
    ];

    if (limit != null && list.length > limit) {
      return list.sublist(0, limit);
    }
    return list;
  }
}

// ==========================================
// 3. MAIN APPLICATION & THEME CONTROLLER
// ==========================================
class NewsApp extends StatefulWidget {
  const NewsApp({super.key});

  static NewsAppState of(BuildContext context) =>
      context.findAncestorStateOfType<NewsAppState>()!;

  @override
  State<NewsApp> createState() => NewsAppState();
}

class NewsAppState extends State<NewsApp> {
  ThemeMode _themeMode = ThemeMode.light;

  ThemeMode get themeMode => _themeMode;

  @override
  void initState() {
    super.initState();
    _loadThemePreference();
  }

  Future<void> _loadThemePreference() async {
    final prefs = await SharedPreferences.getInstance();
    final isDark = prefs.getBool('is_dark_mode') ?? false;
    setState(() {
      _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    });
  }

  Future<void> toggleTheme(bool isDark) async {
    setState(() {
      _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_dark_mode', isDark);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Đọc Báo Online',
      debugShowCheckedModeBanner: false,
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9C1B2A), // Màu đỏ đô nhận diện VnExpress
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF9F9FB),
        appBarTheme: const AppBarTheme(
          elevation: 0.5,
          centerTitle: true,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          titleTextStyle: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.8,
            color: Colors.black87,
          ),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE53935),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF121212),
        appBarTheme: const AppBarTheme(
          elevation: 0.5,
          centerTitle: true,
          backgroundColor: Color(0xFF1E1E1E),
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.8,
            color: Colors.white,
          ),
        ),
      ),
      home: const MainNavigationScreen(),
    );
  }
}

// ==========================================
// 4. MAIN BOTTOM NAVIGATION SCREEN
// ==========================================
class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    CategoryScreen(),
    LatestNewsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              color: isDark ? Colors.white12 : Colors.black12,
              width: 0.5,
            ),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          selectedItemColor: const Color(0xFF9C1B2A),
          unselectedItemColor: isDark ? Colors.white54 : Colors.grey.shade600,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
          unselectedLabelStyle: const TextStyle(fontSize: 12),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.feed_outlined),
              activeIcon: Icon(Icons.feed),
              label: 'Tin tổng hợp',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.account_tree_outlined),
              activeIcon: Icon(Icons.account_tree),
              label: 'Chủ đề',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.show_chart),
              activeIcon: Icon(Icons.timeline),
              label: 'Tin mới nhất',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings_outlined),
              activeIcon: Icon(Icons.settings),
              label: 'Cài đặt',
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 5. SCREEN 1: MÀN HÌNH CHÍNH (TIN TỔNG HỢP)
// ==========================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Article> _articles = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadNews();
  }

  Future<void> _loadNews() async {
    setState(() => _isLoading = true);
    // Sử dụng luồng tin mới nhất/tổng hợp chính xác từ VnExpress RSS
    final data = await RssService.fetchArticles(
      'https://vnexpress.net/rss/tin-moi-nhat.rss',
      category: 'Tổng hợp',
    );
    if (mounted) {
      setState(() {
        _articles = data;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ĐỌC BÁO ONLINE'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Làm mới',
            onPressed: _loadNews,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF9C1B2A)),
            )
          : RefreshIndicator(
              color: const Color(0xFF9C1B2A),
              onRefresh: _loadNews,
              child: ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                itemCount: _articles.length,
                separatorBuilder: (context, index) => const Divider(
                  height: 20,
                  thickness: 0.6,
                  color: Colors.black12,
                ),
                itemBuilder: (context, index) {
                  final article = _articles[index];
                  return NewsListItem(
                    article: article,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailScreen(article: article),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
    );
  }
}

// ==========================================
// 6. SCREEN 2: MÀN HÌNH THEO CHỦ ĐỀ
// ==========================================
class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  int _selectedCategoryIndex = 0;
  List<Article> _categoryArticles = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadCategoryNews(0);
  }

  Future<void> _loadCategoryNews(int index) async {
    setState(() {
      _selectedCategoryIndex = index;
      _isLoading = true;
    });

    final cat = RssService.categories[index];
    final data = await RssService.fetchArticles(cat.rssUrl, category: cat.name);

    if (mounted) {
      setState(() {
        _categoryArticles = data;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('TIN THEO CHỦ ĐỀ'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Làm mới',
            onPressed: () => _loadCategoryNews(_selectedCategoryIndex),
          ),
        ],
      ),
      body: Column(
        children: [
          // Horizontal Category Selector
          Container(
            height: 52,
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
              border: Border(
                bottom: BorderSide(
                  color: isDark ? Colors.white10 : Colors.black12,
                  width: 0.6,
                ),
              ),
            ),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              itemCount: RssService.categories.length,
              itemBuilder: (context, index) {
                final cat = RssService.categories[index];
                final isSelected = _selectedCategoryIndex == index;

                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    selected: isSelected,
                    showCheckmark: false,
                    avatar: Icon(
                      cat.icon,
                      size: 16,
                      color: isSelected ? Colors.white : (isDark ? Colors.white70 : Colors.black87),
                    ),
                    label: Text(
                      cat.name,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        color: isSelected ? Colors.white : (isDark ? Colors.white70 : Colors.black87),
                      ),
                    ),
                    backgroundColor: isDark ? const Color(0xFF2C2C2C) : Colors.grey.shade100,
                    selectedColor: const Color(0xFF9C1B2A),
                    side: BorderSide(
                      color: isSelected
                          ? const Color(0xFF9C1B2A)
                          : (isDark ? Colors.white12 : Colors.grey.shade300),
                      width: 0.8,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    onSelected: (selected) {
                      if (!isSelected) {
                        _loadCategoryNews(index);
                      }
                    },
                  ),
                );
              },
            ),
          ),

          // Article List for Selected Category
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(color: Color(0xFF9C1B2A)),
                  )
                : RefreshIndicator(
                    color: const Color(0xFF9C1B2A),
                    onRefresh: () => _loadCategoryNews(_selectedCategoryIndex),
                    child: _categoryArticles.isEmpty
                        ? const Center(
                            child: Text('Không có tin tức nào trong chuyên mục này'),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                            itemCount: _categoryArticles.length,
                            separatorBuilder: (context, index) => const Divider(
                              height: 20,
                              thickness: 0.6,
                              color: Colors.black12,
                            ),
                            itemBuilder: (context, index) {
                              final article = _categoryArticles[index];
                              return NewsListItem(
                                article: article,
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => DetailScreen(article: article),
                                    ),
                                  );
                                },
                              );
                            },
                          ),
                  ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 7. SCREEN 3: MÀN HÌNH TIN MỚI NHẤT (10 TIN)
// ==========================================
class LatestNewsScreen extends StatefulWidget {
  const LatestNewsScreen({super.key});

  @override
  State<LatestNewsScreen> createState() => _LatestNewsScreenState();
}

class _LatestNewsScreenState extends State<LatestNewsScreen> {
  List<Article> _latestArticles = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadLatestNews();
  }

  Future<void> _loadLatestNews() async {
    setState(() => _isLoading = true);
    // Yêu cầu: Hiển thị đúng 10 tin mới nhất
    final data = await RssService.fetchArticles(
      'https://vnexpress.net/rss/tin-moi-nhat.rss',
      limit: 10,
      category: 'Mới nhất',
    );
    if (mounted) {
      setState(() {
        _latestArticles = data;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('10 TIN MỚI NHẤT'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Làm mới',
            onPressed: _loadLatestNews,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF9C1B2A)),
            )
          : RefreshIndicator(
              color: const Color(0xFF9C1B2A),
              onRefresh: _loadLatestNews,
              child: ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                itemCount: _latestArticles.length,
                separatorBuilder: (context, index) => const Divider(
                  height: 20,
                  thickness: 0.6,
                  color: Colors.black12,
                ),
                itemBuilder: (context, index) {
                  final article = _latestArticles[index];
                  return NewsListItem(
                    article: article,
                    rankIndex: index + 1,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailScreen(article: article),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
    );
  }
}

// ==========================================
// 8. SCREEN 4: MÀN HÌNH CÀI ĐẶT
// ==========================================
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = NewsApp.of(context);
    final isDark = appState.themeMode == ThemeMode.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('CÀI ĐẶT'),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        children: [
          // Giao diện
          Text(
            'GIAO DIỆN',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: isDark ? Colors.white60 : Colors.black54,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: SwitchListTile(
              secondary: Icon(
                isDark ? Icons.dark_mode : Icons.light_mode,
                color: const Color(0xFF9C1B2A),
              ),
              title: const Text(
                'Chế độ nền tối (Dark Mode)',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
              ),
              subtitle: Text(
                isDark ? 'Đang bật nền tối' : 'Đang bật nền sáng',
                style: const TextStyle(fontSize: 13),
              ),
              value: isDark,
              activeThumbColor: const Color(0xFF9C1B2A),
              onChanged: (value) {
                appState.toggleTheme(value);
              },
            ),
          ),

          const SizedBox(height: 24),

          // Thông tin ứng dụng & sinh viên
          Text(
            'THÔNG TIN SINH VIÊN & ỨNG DỤNG',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: isDark ? Colors.white60 : Colors.black54,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _buildInfoRow(
                    context,
                    icon: Icons.person_outline,
                    title: 'Họ và tên',
                    value: 'Nguyễn Hoàng Thân',
                    isHighlight: true,
                  ),
                  const Divider(height: 22, thickness: 0.6),
                  _buildInfoRow(
                    context,
                    icon: Icons.badge_outlined,
                    title: 'Mã số sinh viên (MSSV)',
                    value: '2424801030021',
                    isHighlight: true,
                  ),
                  const Divider(height: 22, thickness: 0.6),
                  _buildInfoRow(
                    context,
                    icon: Icons.class_outlined,
                    title: 'Lớp sinh hoạt',
                    value: 'D24KTPM02',
                    isHighlight: true,
                  ),
                  const Divider(height: 22, thickness: 0.6),
                  _buildInfoRow(
                    context,
                    icon: Icons.assignment_outlined,
                    title: 'Học phần / Đề tài',
                    value: 'Bài tập 4: Ứng dụng đọc báo online (VnExpress RSS)',
                  ),
                  const Divider(height: 22, thickness: 0.6),
                  _buildInfoRow(
                    context,
                    icon: Icons.rss_feed,
                    title: 'Nguồn cấp dữ liệu',
                    value: 'VnExpress RSS Newsfeed',
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          // About app
          Center(
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF9C1B2A).withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.newspaper,
                    color: Color(0xFF9C1B2A),
                    size: 36,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'VnExpress News Reader',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 4),
                Text(
                  'Phiên bản 1.0.0 • Ứng dụng di động đa nền tảng',
                  style: TextStyle(
                    fontSize: 12,
                    color: isDark ? Colors.white54 : Colors.black54,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String value,
    bool isHighlight = false,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 22, color: const Color(0xFF9C1B2A)),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? Colors.white60 : Colors.black54,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                value,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: isHighlight ? FontWeight.bold : FontWeight.w500,
                  color: isHighlight
                      ? (isDark ? Colors.amber.shade300 : const Color(0xFF9C1B2A))
                      : (isDark ? Colors.white : Colors.black87),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ==========================================
// 9. SCREEN 5: MÀN HÌNH CHI TIẾT TIN TỨC (HỖ TRỢ ĐỌC TRỰC TIẾP TRÊN APP QUA WEBVIEW)
// ==========================================
class DetailScreen extends StatefulWidget {
  final Article article;

  const DetailScreen({super.key, required this.article});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  List<String> _paragraphs = [];
  bool _isLoadingContent = true;

  @override
  void initState() {
    super.initState();
    _loadArticleContent();
  }

  Future<void> _loadArticleContent() async {
    if (widget.article.link.isEmpty) {
      if (mounted) setState(() => _isLoadingContent = false);
      return;
    }

    try {
      final res = await http.get(
        Uri.parse(widget.article.link),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final body = utf8.decode(res.bodyBytes);
        final pMatches = RegExp(r'<p class="Normal"[^>]*>(.*?)<\/p>', dotAll: true).allMatches(body);
        final list = <String>[];
        for (final p in pMatches) {
          var text = p.group(1)!.replaceAll(RegExp(r'<[^>]*>'), '').trim();
          text = text
              .replaceAll('&quot;', '"')
              .replaceAll('&apos;', "'")
              .replaceAll('&#39;', "'")
              .replaceAll('&amp;', '&')
              .replaceAll('&lt;', '<')
              .replaceAll('&gt;', '>')
              .replaceAll('&nbsp;', ' ');
          if (text.isNotEmpty) {
            list.add(text);
          }
        }
        if (mounted && list.isNotEmpty) {
          setState(() {
            _paragraphs = list;
            _isLoadingContent = false;
          });
          return;
        }
      }
    } catch (_) {}

    if (mounted) {
      setState(() => _isLoadingContent = false);
    }
  }

  Future<void> _openExternalBrowser(BuildContext context, String url) async {
    if (url.isEmpty) return;
    final uri = Uri.parse(url);
    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không thể mở liên kết bài viết')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Đã có lỗi khi mở trình duyệt')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('CHI TIẾT TIN TỨC'),
        actions: [
          IconButton(
            icon: const Icon(Icons.open_in_browser),
            tooltip: 'Mở trên trình duyệt',
            onPressed: () => _openExternalBrowser(context, widget.article.link),
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          // Header Image
          if (widget.article.imageUrl != null && widget.article.imageUrl!.isNotEmpty)
            Image.network(
              widget.article.imageUrl!,
              width: double.infinity,
              height: 240,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                width: double.infinity,
                height: 180,
                color: isDark ? Colors.white10 : Colors.grey.shade200,
                child: const Center(
                  child: Icon(Icons.newspaper, size: 48, color: Colors.grey),
                ),
              ),
            ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Source & Category & PubDate
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFF9C1B2A),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        widget.article.category,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(
                      Icons.access_time,
                      size: 14,
                      color: isDark ? Colors.white60 : Colors.grey.shade600,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      widget.article.pubDate,
                      style: TextStyle(
                        fontSize: 12,
                        color: isDark ? Colors.white60 : Colors.grey.shade600,
                      ),
                    ),
                    const Spacer(),
                    const Text(
                      'VnExpress',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF9C1B2A),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 14),

                // Title
                Text(
                  widget.article.title,
                  style: const TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                    height: 1.35,
                  ),
                ),

                const SizedBox(height: 16),

                // Lead summary card (Sapo)
                if (widget.article.description.isNotEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF1E1E1E) : const Color(0xFFF1F3F5),
                      borderRadius: BorderRadius.circular(8),
                      border: const Border(
                        left: BorderSide(
                          color: Color(0xFF9C1B2A),
                          width: 4,
                        ),
                      ),
                    ),
                    child: Text(
                      widget.article.description,
                      style: TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w600,
                        fontStyle: FontStyle.italic,
                        height: 1.5,
                        color: isDark ? Colors.white70 : Colors.black87,
                      ),
                    ),
                  ),

                const SizedBox(height: 22),

                // Full Article Body Paragraphs
                if (_isLoadingContent)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFF9C1B2A),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'Đang tải nội dung chi tiết bài báo...',
                          style: TextStyle(
                            fontSize: 13,
                            color: isDark ? Colors.white60 : Colors.grey.shade700,
                          ),
                        ),
                      ],
                    ),
                  )
                else if (_paragraphs.isNotEmpty)
                  ..._paragraphs.map(
                    (paragraph) => Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(
                        paragraph,
                        style: TextStyle(
                          fontSize: 16,
                          height: 1.65,
                          color: isDark ? Colors.white.withValues(alpha: 0.9) : const Color(0xFF222222),
                        ),
                      ),
                    ),
                  )
                else ...[
                  // If full body couldn't be loaded (e.g. offline)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Text(
                      'Nội dung tóm tắt đã được hiển thị ở trên. Để đọc phiên bản gốc, vui lòng bấm nút bên dưới:',
                      style: TextStyle(
                        fontSize: 14,
                        color: isDark ? Colors.white60 : Colors.grey.shade700,
                      ),
                    ),
                  ),
                ],

                const SizedBox(height: 16),
                const Divider(thickness: 0.6),
                const SizedBox(height: 14),

                // Footer source info
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Theo VnExpress',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: isDark ? Colors.white70 : Colors.black87,
                      ),
                    ),
                    Text(
                      'Báo điện tử tiếng Việt',
                      style: TextStyle(
                        fontSize: 12,
                        fontStyle: FontStyle.italic,
                        color: isDark ? Colors.white38 : Colors.grey,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                // Button to open on browser
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF9C1B2A),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      elevation: 1,
                    ),
                    icon: const Icon(Icons.launch, size: 20),
                    label: const Text(
                      'MỞ BÀI VIẾT TRÊN TRÌNH DUYỆT',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                    onPressed: () => _openExternalBrowser(context, widget.article.link),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 10. REUSABLE WIDGET: NEWS LIST ITEM
// ==========================================
class NewsListItem extends StatelessWidget {
  final Article article;
  final VoidCallback onTap;
  final int? rankIndex;

  const NewsListItem({
    super.key,
    required this.article,
    required this.onTap,
    this.rankIndex,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Ranking Badge (for 10 Latest News)
            if (rankIndex != null) ...[
              Container(
                width: 26,
                height: 26,
                margin: const EdgeInsets.only(right: 10, top: 2),
                decoration: BoxDecoration(
                  color: rankIndex! <= 3
                      ? const Color(0xFF9C1B2A)
                      : (isDark ? Colors.white24 : Colors.grey.shade400),
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  '$rankIndex',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ],

            // Title & Meta Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    article.title,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w700,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'VnExpress • ${article.pubDate}',
                    style: TextStyle(
                      fontSize: 11.5,
                      color: isDark ? Colors.white54 : const Color(0xFF757575),
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 12),

            // Thumbnail Image on the right (matches PDF screenshot)
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Container(
                width: 105,
                height: 72,
                color: isDark ? Colors.white10 : Colors.grey.shade200,
                child: article.imageUrl != null && article.imageUrl!.isNotEmpty
                    ? Image.network(
                        article.imageUrl!,
                        fit: BoxFit.cover,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Center(
                            child: SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: const Color(0xFF9C1B2A),
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded /
                                        loadingProgress.expectedTotalBytes!
                                    : null,
                              ),
                            ),
                          );
                        },
                        errorBuilder: (context, error, stackTrace) => Container(
                          color: isDark ? Colors.white10 : Colors.grey.shade300,
                          child: const Icon(Icons.newspaper, color: Colors.grey, size: 28),
                        ),
                      )
                    : Container(
                        color: isDark ? Colors.white10 : Colors.grey.shade300,
                        child: const Icon(Icons.newspaper, color: Colors.grey, size: 28),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
